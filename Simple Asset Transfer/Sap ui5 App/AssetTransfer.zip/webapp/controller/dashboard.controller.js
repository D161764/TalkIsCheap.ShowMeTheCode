sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("AssetTransfer.controller.dashboard", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf AssetTransfer.view.dashboard
		 */
		onInit: function() {
			var that = this;
			var tilesdata = {
				"TileCollection": [{

					"icon": "sap-icon://monitor-payments",
					"number": "",
					"numberUnit": "",
					"title": "Assets and Participants",
					"info": "Create and View"
				}, {
					"icon": "sap-icon://money-bills",
					"number": "",
					"numberUnit": "",
					"title": "Transactions",
					"info": "Submit and view records"
				}]

			};

			var tilesmodel = new JSONModel();
			tilesmodel.setData(tilesdata);
			that.getView().byId("container").setModel(tilesmodel);
		},
		_doRoute: function(view_target) {
			var that = this;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo(view_target);
		},
		OnTilePress: function(evt) {
			var that = this;
			
			var mtitle = evt.oSource.mProperties.title;
			if (mtitle === "Assets and Participants") {
				that._doRoute("create");
			} else {
				that._doRoute("transaction");
			}
			
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf AssetTransfer.view.dashboard
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf AssetTransfer.view.dashboard
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf AssetTransfer.view.dashboard
		 */
		//	onExit: function() {
		//
		//	}

	});

});