sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("AssetTransfer.controller.SubmitTransaction", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf AssetTransfer.view.SubmitTransaction
		 */
		onInit: function() {
			this.DisplayTransaction();

		},
		OnIconTr: function(evt) {
			var that = this;
			var select_icontr = evt.oSource.mProperties.selectedKey;
			if (select_icontr === "__xmlview2--disp_transact") {
				that.DisplayTransaction();
			}

		},
		onCloseDialog: function() {
			var that = this;
			that.uservhdialog.close();
		},
		// _handleValueHelpClose: function(evt) {
		// 	var that = this;
		// 	var oSelectedItem = evt.getParameter("selectedItem");
		// 	if (oSelectedItem) {
		// 		var productInput = this.getView().byId(this.inputId);
		// 		productInput.setValue(oSelectedItem.getTitle());
		// 	}
		// 	this.uservhdialog.close();
		// },
		onListItemPress: function(evt) {
			var that = this;
			var selectUserId = evt.oSource.mProperties.title;
			that.onCloseDialog();
			that.getView().byId("uid").setValue(selectUserId);

		},
		OnTrade: function() {
			var that = this;
			sap.ui.core.BusyIndicator.show(1);
			var trade_url = "/HyperLedgerFabric/api/trade";
			var user_id = this.getView().byId("uid").getValue();
			var asset_id = this.getView().byId("asset_input").getValue();
			var trade_payload = {
				"$class": "org.devauction.trade",
				"newuserid":  user_id,
				"trcomodity": asset_id
			};
				$.ajax({
				type: "Post",
				contentType: "application/json",
				accept: "application/json",
				data: JSON.stringify(trade_payload),
				url: trade_url,
				success: function(data, textStatus, jqXHR) {
					sap.ui.core.BusyIndicator.hide();
					var mbtext = "New Trade Has been made";
					sap.m.MessageToast.show(mbtext, {
						duration: 3000
					});
					that.getView().byId("uid").setValue("");
					that.getView().byId("asset_input").setValue("");
					
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});
		},
		SetUserDialogValue: function() {
			sap.ui.core.BusyIndicator.show(1);
			var that = this;
			var user_url = "/HyperLedgerFabric/api/user";
			var userModel = new JSONModel();
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: user_url,
				success: function(data, textStatus, jqXHR) {
					userModel.setData(data);
					sap.ui.getCore().byId("userditbl").setModel(userModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});
		},
		handleValueHelpUser: function() {
			var that = this;
			if (!this.uservhdialog) {
				this.uservhdialog = sap.ui.xmlfragment("AssetTransfer.view.uservh", this.getView().getController());

			}
			this.uservhdialog.open();
			that.SetUserDialogValue();
		},
		DisplayTransaction: function() {
			var that = this;
			var trade_url = "/HyperLedgerFabric/api/trade";
			sap.ui.core.BusyIndicator.show(1);
			var trmodel = new JSONModel();
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: trade_url,
				success: function(data, textStatus, jqXHR) {
					trmodel.setData(data);
					that.getView().byId("transaction_table").setModel(trmodel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});
		},
		onnavBack2: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("dashboard");
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf AssetTransfer.view.SubmitTransaction
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf AssetTransfer.view.SubmitTransaction
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf AssetTransfer.view.SubmitTransaction
		 */
		//	onExit: function() {
		//
		//	}

	});

});