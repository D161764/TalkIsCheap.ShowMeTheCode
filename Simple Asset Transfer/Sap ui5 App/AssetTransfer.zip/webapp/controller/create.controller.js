sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("AssetTransfer.controller.create", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf AssetTransfer.view.create
		 */
		onInit: function() {
			var that = this;
			// Getting User List Start
			var user_url = "/HyperLedgerFabric/api/user";
			sap.ui.core.BusyIndicator.show(1);
			var userModel = new JSONModel();
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: user_url,
				success: function(data, textStatus, jqXHR) {
					userModel.setData(data);
					that.getView().byId("participant_table").setModel(userModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});
			// Getting User List End

			// Getting Asset List Start

			// Getting Asset List End

		},
		DisplayUser: function() {
			sap.ui.core.BusyIndicator.show(1);
			var that = this;
			var user_url = "/HyperLedgerFabric/api/user";
			var userModel = new JSONModel();
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: user_url,
				success: function(data, textStatus, jqXHR) {
					userModel.setData(data);
					that.getView().byId("participant_table").setModel(userModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});

		},

		DisplayAsset: function() {
			sap.ui.core.BusyIndicator.show(1);
			var that = this;
			var asset_url = "/HyperLedgerFabric/api/comodity";
			var assetModel = new JSONModel();
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: asset_url,
				success: function(data, textStatus, jqXHR) {
					assetModel.setData(data);
					that.getView().byId("asset_table").setModel(assetModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});
		},
		CloseDialogUser: function() {
			var that = this;
			that.CancelUserDialog();
			that.DisplayUser();

		},
		
		CloseDialogAsset: function() {
			var that = this;
			that.CancelAssetDialog();
			that.DisplayAsset();
		},
		onUserSave: function() {
			sap.ui.core.BusyIndicator.show(1);
			var user_url = "/HyperLedgerFabric/api/user";
			var that = this;
			var email = sap.ui.getCore().byId("fr_email").getValue();
			var userid = sap.ui.getCore().byId("fr_userid").getValue();
			var fname = sap.ui.getCore().byId("fr_fname").getValue();
			var lname = sap.ui.getCore().byId("fr_lname").getValue();

			var user_payload = {
				"$class": "org.devauction.user",
				"email": email,
				"firstname": fname,
				"lastname": lname,
				"userid": userid
			};
			$.ajax({
				type: "Post",
				contentType: "application/json",
				accept: "application/json",
				data: JSON.stringify(user_payload),
				url: user_url,
				success: function(data, textStatus, jqXHR) {
					sap.ui.core.BusyIndicator.hide();
					var mbtext = "New Participant created";
					sap.m.MessageToast.show(mbtext, {
						duration: 3000
					});
					that.CloseDialogUser();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});

		},
		onAssetSave: function() {
			sap.ui.core.BusyIndicator.show(1);
			var asset_url = "/HyperLedgerFabric/api/comodity";
			var that = this;
			var assetid = sap.ui.getCore().byId("fr_gassetid").getValue();
			var assetvalue = sap.ui.getCore().byId("fr_avalue").getValue();
			var assetdesc = sap.ui.getCore().byId("fr_adesc").getValue();
			var aowner = sap.ui.getCore().byId("fr_aowner").getValue();

			var asset_payload = {
				"$class": "org.devauction.comodity",
				"assetId": assetid,
				"value": assetvalue,
				"description": assetdesc,
				"owner": aowner
			};
			$.ajax({
				type: "Post",
				contentType: "application/json",
				accept: "application/json",
				data: JSON.stringify(asset_payload),
				url: asset_url,
				success: function(data, textStatus, jqXHR) {
					sap.ui.core.BusyIndicator.hide();
					var mbtext = "New Asset Has been Created";
					sap.m.MessageToast.show(mbtext, {
						duration: 3000
					});
					that.CloseDialogAsset();
				},
				error: function(jqXHR, textStatus, errorThrown) {

				}

			});
		},

		CancelUserDialog: function() {
			this.userdialog.close();
		},
		CancelAssetDialog: function() {
			this.assetdialog.close();
		},
		onAddParticipant: function() {
			var that = this;
			var oview = this.getView();
			if (!this.userdialog) {
				this.userdialog = sap.ui.xmlfragment("AssetTransfer.view.CreateUser",this.getView().getController());

			}
			this.userdialog.open();

		},

		onAddAsset: function() {
			var that = this;
			var oview = this.getView();
			if (!this.assetdialog) {
				this.assetdialog = sap.ui.xmlfragment("AssetTransfer.view.CreateAsset",this.getView().getController());

			}
			this.assetdialog.open();
		},

		onnavBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("dashboard");
		},
		onIcon: function(evt) {
			var that = this;
			var select_icon = evt.oSource.mProperties.selectedKey;

			if (select_icon === "__xmlview2--icon_asset") {

				that.DisplayAsset();

			} else {

				that.DisplayUser();

			}

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf AssetTransfer.view.create
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf AssetTransfer.view.create
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf AssetTransfer.view.create
		 */
		//	onExit: function() {
		//
		//	}

	});

});